document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('.company-contact-form');
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        sendFormData();
    });

    function sendFormData() {
        const formData = new FormData(form);
        fetch('assets/mail/company-submission.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Handle the response data, e.g., display success or error message
            console.log(data);
            document.getElementById('message').innerHTML = data.message;
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
});
