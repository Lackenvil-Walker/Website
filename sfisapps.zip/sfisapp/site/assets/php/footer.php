<footer class="default-padding-top text-light">
        <div class="container">
            <div class="row">
                <div class="f-items fv1">
                    <div class="col-md-3 item">
                        <img src="assets/img/logo-light.svg" style="padding-bottom: 30px;">
                    </div>
                    <div class="col-md-3 item">
                        <div class="f-item link full">
                            <h4>Overview</h4>
                            <ul>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="services.php">Managed IT Services</a></li>
                                <li><a href="recruitment.php">Recruitment</a></li>
                                <li><a href="training.php">Training</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 item">
                        <div class="f-item link full">
                            <h4>Helpful Links</h4>
                            <ul>
                                <li><a href="alintatech-solutions-company-profile.pdf" target="_blank" >Company Profile</a></li>
                                <li><a href="alintatech-solutions-services-brochure.pdf" target="_blank" >Services Brochure</a></li>
                                <li><a href="quote.php">Request a Quote</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 item">
                        <div class="f-item">
                            <h4>Contact Information</h4>
                            <div class="twitter-item">
                                <div class="twitter-content">                
                                    <p>
                                        <a href="https://goo.gl/maps/Y2MnniBL7X3uRQQw7" target="_blank"><i class="fas fa-map-marker-alt" style="padding-right: 20px;"></i>First Floor, LOVAT House<br>31 Wessels Road, Rivonia<br>Sandton, Johannesburg, 2128<br>South Africa</a>
                                    </p>
                                    <p>
                                        <a href="tel:27871645894"><i class="fas fa-mobile-alt" style="padding-right: 20px;"></i>+27 87 809 1201</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <strong>
                            <div class="col-md-12">
                                <strong>
                                    <p class="text-center">Alintatech Solutions. &copy; <?php echo date("Y"); ?></p>
                                </strong>
                            </div>
                        </strong>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
