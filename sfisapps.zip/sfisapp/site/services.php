<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-1W8M9S5KQY"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-1W8M9S5KQY');
    </script>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Alintatech Solutions Website">

    <!-- ========== Page Title ========== -->
    <title>Alintatech Solutions | Services</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicon/site.webmanifest">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/css/flaticon-business-set.css" rel="stylesheet" />
    <link href="assets/css/magnific-popup.css" rel="stylesheet" />
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/animate.css" rel="stylesheet" />
    <link href="assets/css/bootsnav.css" rel="stylesheet" />
    <link href="style.css" rel="stylesheet">
    <link href="custom.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="assets/js/html5/html5shiv.min.js"></script>
      <script src="assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,900" rel="stylesheet">

</head>

<body>

    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-angle-double-up"></i></button>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <?php include 'assets/php/header.php' ?>

    <!-- Start About 
    ============================================= -->
    <div class="about-area bg-gray services-include default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 services text-center">
                    <div class="col-md-3 equal-height">
                        <a href="#managed-it-support">
                            <img src="assets/img/icon/003-technical-support.svg" class="center">
                            <h4>Managed IT Support</h4>
                        </a>
                    </div>
                    <div class="col-md-3 equal-height">
                        <a href="#software-development">
                            <img src="assets/img/icon/007-coding.svg" class="center">
                            <h4>Software Development</h4>
                        </a>
                    </div>
                    <div class="col-md-3 equal-height">
                        <a href="#it-recruitment">
                            <img src="assets/img/icon/006-recruitment-1.svg" class="center">
                            <h4>360<br>Recruitment</h4>
                        </a>
                    </div>
                    <div class="col-md-3 equal-height">
                        <a href="#specialist-services">
                            <img src="assets/img/icon/008-accounting.svg" class="center">
                            <h4>Specialist Services</h4>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start Blog
    ============================================= -->
    <div class="blog-area full-blog right-sidebar full-blog default-padding">
        <div class="container">
            <div class="row">
                <div id="managed-it-support" class="blog-items">
                    <div class="blog-content col-12">
                        <div class="item-box" style="style box-shadow: 0 0 10px #cccccc;" >
                            <div class="item">
                                <div class="thumb">
                                        <img src="assets/img/managed-services.webp" alt="Thumbnail">
                                </div>
                                <div class="row">
                                    <div class="alinta col-md-8">
                                        <h4>
                                            MANAGED IT SUPPORT SERVICES
                                        </h4>
                                        <p>
                                            <strong style="color: black;">
                                                Server Management | Strategic IT Advisory |Cloud Services | Network Management | IT Security |Office 365 | VOIP| Fibre and other Data solutions
                                            </strong>
                                        </p>
                                        <p>
                                        The Alinta Tech Engineers and Technicians are dedicated and friendly professionals with expertise in Server Management, Strategic IT advisory, Cloud Services, Network Management and IT Security, Office 365, VOIP and many other end user technologies. This enables Alinta Tech to provide a full range of managed services from desktop support to small business through to fully outsourced IT to medium-sized enterprises in and around Gauteng mostly, but at selected localities outside Gauteng. Tell us about your technology challenges and we will design a solution that will harness the technology to take your company forward.
                                        </p>
                                    </div>
                                    <div class="alinta col-md-4">
                                        <p>
                                            <strong style="color: black;">
                                                Benefits
                                            </strong>
                                        </p>
                                        <p>
                                            <ul>
                                                <li><i class="fas fa-angle-right"></i>  Access to skills and advanced technology services not available in-house.</li>
                                                <li><i class="fas fa-angle-right"></i>  Reduced capital expenditure.</li>
                                                <li><i class="fas fa-angle-right"></i>  Opportunity to accelerate and support innovation.</li>
                                                <li><i class="fas fa-angle-right"></i>  Access to industry standard tools for IT monitoring and management.</li>
                                                <li><i class="fas fa-angle-right"></i>  Transfer of risk and service level to IT provider.</li>
                                                <li><i class="fas fa-angle-right"></i>  Improved flexibility in use of resources and focusing on core business.</li>
                                            </ul>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div  id="it-recruitment" class="blog-items">
                    <div class="blog-content col-12">
                        <div class="item-box" style="style box-shadow: 0 0 10px #cccccc;" >
                            <div class="item">
                                <div class="thumb">
                                        <img src="assets/img/it-staffing.webp" alt="Thumbnail">
                                </div>
                                <div class="row">
                                    <div class="alinta col-md-8">
                                        <h4>
                                            OUTSOURCED IT STAFFING
                                        </h4>
                                        <p>
                                            <strong style="color: black;">
                                                Permanent Staff Placement | Interim Talent Placement | Outsourced IT Staff
                                            </strong>
                                        </p>
                                        <p>
                                            We keep your recruitment need simple. As an established Managed IT solutions company, first and foremost, Alinta Tech has a better understanding than most about finding and placing hard-to-find permanent and contract IT talent. We can quickly find you highly skilled IT professionals who are the best fit for your project or permanent hiring needs. Using skills testing combined with the knowledge of our dedicated specialist technology recruitment consultants, we can match the right technology professional with the right role.
                                        </p>
                                        <p>
                                            <strong style="color: black;">
                                                Permanent Placement
                                            </strong>
                                        </p>
                                        <p>
                                            <ul>
                                                <li><i class="fas fa-angle-right"></i>  Adding to your team can be fast and easy.</li>
                                                <li><i class="fas fa-angle-right"></i>  Local talent specialists — We handle the entire hiring process for you, from promoting your job and company to extending offers and negotiating pay.</li>
                                            </ul>
                                        </p>
                                    </div>
                                    <div class="alinta col-md-4">
                                        
                                        <p>
                                            <strong style="color: black;">
                                                Interim Talent Placement
                                            </strong>
                                        </p>
                                        <p>
                                            <ul>
                                                <li><i class="fas fa-angle-right"></i>  Hire for your short-term, temp, fixed-term contractor, or project needs.</li>
                                                <li><i class="fas fa-angle-right"></i>  Flexible, on-demand recruitment to help manage dynamic workloads, project work or employee absences.</li>
                                            </ul>
                                        </p>
                                        <p>
                                            <strong style="color: black;">
                                                Outsourced Staffing
                                            </strong>
                                        </p>
                                        <ul>
                                            <li><i class="fas fa-angle-right"></i>  Adding to your team can be fast and easy.</li>
                                            <li><i class="fas fa-angle-right"></i>  Local talent specialists — We handle the entire hiring process for you, from promoting your job and company to extending offers and negotiating pay.</li>
                                        </ul>

                                    </div>
                                </div>
                                <a data-animation="animated slideInUp" class="btn btn-theme effect btn-sm" href="recruitment.php">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="software-development" class="blog-items">
                    <div class="blog-content col-12">
                        <div class="item-box" style="style box-shadow: 0 0 10px #cccccc;" >
                            <div class="item">
                                <div class="thumb">
                                        <img src="assets/img/software-services.webp" alt="Thumbnail">
                                </div>
                                <div class="row">
                                    <div class="alinta col-md-8">
                                        <h4>
                                            SOFTWARE DEVELOPMENT
                                        </h4>
                                        <p>
                                            <strong style="color: black;">
                                                Business Applications Development and Integration | Web applications
                                            </strong>
                                        </p>
                                        <p>
                                            Alinta Tech offers professional and affordable software development solutions. We can assist you with most software development and integration. We offer affordable payment option that can be incorporated into your existing SLA or paid off over 12 to 24 months depending on the scale of work.
                                        </p>
                                    </div>
                                    <div class="alinta col-md-4">    
                                        <p>
                                            Payment options can be negotiated depending on client's budgetary position. For example:  
                                        </p>    
                                        <p>
                                            <ul>
                                                <li><i class="fas fa-angle-right"></i>  Capex: 50% deposit on commencement of software development cycle and the difference after completion. A software support contract is optional.</li>
                                                <li><i class="fas fa-angle-right"></i>  Opex: Relatively smaller monthly fee over a renewable contractual period of 12 or 24 months paid off in the contract period and includes software support.</li>
                                            </ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="blog-items">
                    <div class="blog-content col-12">
                        <div class="item-box" style="style box-shadow: 0 0 10px #cccccc;" >
                            <div class="item">
                                <div class="thumb">
                                        <img src="assets/img/it-relocation.webp" alt="Thumbnail">
                                </div>
                                <div class="row">
                                    <div class="alinta col-md-8">
                                        <h4>
                                            IT RELOCATION
                                        </h4>
                                        <p>
                                            <strong style="color: black;">
                                                Safe and secure IT relocation with minimal disruption.
                                            </strong>
                                        </p>
                                        <p>
                                            Alinta Tech can plan and manage your IT relocation in Gauteng and surrounding areas. Our expert team will plan and manage every detail of a move, ensuring disruption to business activity is kept to a minimum by performing critical tasks out of hours where necessary. We de-rack and re-rack servers, asset tag hardware, and securely remove and dispose of redundant equipment if required. Safe and secure transport of IT equipment is arranged with our trusted logistics partner. Full cabling solutions are available, and we often perform pre-patch cabling ahead of time to get clients up and running as quickly as possible.
                                        </p>
                                    </div>
                                    <div class="alinta col-md-4">
                                        <p>
                                            <strong style="color: black;">
                                                Secure server and infrastructure relocation.
                                            </strong>
                                        </p>          
                                        <p>
                                            <ul>
                                                <li><i class="fas fa-angle-right"></i>  Full cabling solutions.</li>
                                                <li><i class="fas fa-angle-right"></i>  Technical project management.</li>
                                                <li><i class="fas fa-angle-right"></i>  Out of hours available for minimal disruption.</li>
                                            </ul>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="specialist-services" class="blog-items">
                    <div class="blog-content col-12">
                        <div class="item-box" style="style box-shadow: 0 0 10px #cccccc;" >
                            <div class="item">
                                <div class="thumb">
                                        <img src="assets/img/specialist-services.webp" alt="Thumbnail">
                                </div>
                                <div class="row">
                                    <div class="alinta col-md-8">
                                        <h4>
                                            SPECIALIST SERVICES
                                        </h4>
                                        <p>
                                            <strong style="color: black;">
                                                Payroll Management - Sage Pastel & VIP | SAP Services
                                            </strong>
                                        </p>
                                        <p>
                                            Why should you outsource your payroll?
                                        </p>
                                        <p>
                                            Small to medium sized businesses often experience trouble ensuring that their payroll adheres to the strict and complicated regulations as stipulated by SARS. Large businesses can afford to maintain large payroll departments, but for small businesses an in-house payroll service can prove to be a money burner. For a monthly retainer, Alinta Tech will run an efficient payroll process, which omplies with various legislative requirements and caters for most African countries' tax requirements, resulting in a more accurate budget for your overhead costs, on the basis of a fixed retainer. Our monthly fees are charged per employee, or we charge a minimum fee.
                                        </p>
                                        <p>
                                            <strong style="color: black;">
                                                SAP Services
                                            </strong>
                                        </p>          
                                        <p>
                                            With the right expertise and support, SAP solutions can help you quickly and successfully carry out your digital transformation. Find out what Alinta Tech can do for you as your SAP partner.
                                        </p>
                                        <p>
                                            We Tailor-make customer SAP Implementation Strategy.
                                        </p>
                                        <p>
                                            At the start of every project, we go the extra mile to gain a thorough understanding of our customers' business processes - because every business is different. Based on the strategy of consistent one method project methodology, we can create a tailored implementation strategy that helps you achieve your objectives quickly and efficiently. Our experts use SAP implementation best practices to ensure fast, cost-effective project completion. Finally, we train your employees to maximize their productivity - and can provide ongoing support and consulting after the go-live.
                                        </p>
                                    </div>
                                    <div class="alinta col-md-4">
                                        <p>
                                            <strong style="color: black;">
                                                Payroll Services
                                            </strong>
                                        </p>          
                                        <p>
                                            With Alinta Tech as your payroll partner, we are able to provide these services:
                                        </p>
                                        <ul>
                                            <li><i class="fas fa-angle-right"></i>  General ledger interface.</li>
                                            <li><i class="fas fa-angle-right"></i>  Payroll processing.</li>
                                            <li><i class="fas fa-angle-right"></i>  Payment processing.</li>
                                            <li><i class="fas fa-angle-right"></i>  Leave administration.</li>
                                            <li><i class="fas fa-angle-right"></i>  Statutory compliance.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Blog -->

    <!-- Start Faq  
    ============================================= -->
    <div class="faq-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 appoinment contact-form">
                    <h2>Request a quote</h2>
                    <form action="assets/mail/contact.php" method="POST" class="contact-form">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="name" name="name" placeholder="Name" type="text">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="email" name="email" placeholder="Email*" type="email">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="phone" name="phone" placeholder="Phone" type="text">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group comments">
                                    <textarea class="form-control" id="comments" name="comments" placeholder="Tell Us About Your Project *"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <button type="submit" name="submit" id="submit">
                                    Send Message <i class="fa fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                        <!-- Alert Message -->
                        <div class="col-md-12 alert-notification">
                            <div id="message" class="alert-msg"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Faq  -->

<?php include 'assets/php/footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/equal-height.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/timeline.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/custom.js"></script>

</body>
</html>