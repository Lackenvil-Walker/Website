<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-1W8M9S5KQY"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-1W8M9S5KQY');
    </script>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Alintatech Solutions Website">

    <!-- ========== Page Title ========== -->
    <title>Alintatech Solutions | About Us</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicon/site.webmanifest">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/css/flaticon-business-set.css" rel="stylesheet" />
    <link href="assets/css/magnific-popup.css" rel="stylesheet" />
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/animate.css" rel="stylesheet" />
    <link href="assets/css/bootsnav.css" rel="stylesheet" />
    <link href="style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="assets/js/html5/html5shiv.min.js"></script>
      <script src="assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,900" rel="stylesheet">

</head>

<body>

    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-angle-double-up"></i></button>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <?php include 'assets/php/header.php' ?>

    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-center padding-xl text-light" style="background-image: url(assets/img/about-banner.webp);">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 text-left">
                    <h1>About Us</h1>
                </div>
                <div class="col-md-6 col-sm-6 text-right">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start About 
    ============================================= -->
    <div class="about-area bg-gray services-include default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 default info">
                    <h2>Welcome to <br>Alinta Tech Solutions</h2>
                    <p>
                        Alinta Tech Solutions (also known as Alinta Tech) is a Managed IT Support and Technology Solutions Provider. Our services include comprehensive IT support functions, outsourced IT staffing and technology solutions designed to support the success and growth of small and medium-sized businesses.
                    </p>
                    <p>
                        Alinta Tech is owned by Alintacorp 64 Pty Ltd (www.alintacorp.co.za), which has been offering corporate training to the South African government and the private sector since its inception in August of 2011.
                    </p>
                    <div class="bottom-info">
                        <ul>
                            <li>
                                <a class="btn btn-theme effect btn-sm" href="contact.php">Contact Us</a>
                            </li>
                            <li>
                                <a href="tel:27871645894">
                                    <i class="fas fa-phone"></i> +27 87 164 5894
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 services text-center">
                    <div class="col-md-6 equal-height">
                        <a href="services.php">
                            <img src="assets/img/icon/003-technical-support.svg" class="center">
                            <h4>Managed IT Support</h4>
                        </a>
                    </div>
                    <div class="col-md-6 equal-height">
                        <a href="services.php">
                            <img src="assets/img/icon/007-coding.svg" class="center">
                            <h4>Software Development</h4>
                        </a>
                    </div>
                    <div class="col-md-6 equal-height">
                        <a href="recruitment.php">
                            <img src="assets/img/icon/006-recruitment-1.svg" class="center">
                            <h4>IT<br>Recruitment</h4>
                        </a>
                    </div>
                    <div class="col-md-6 equal-height">
                        <a href="services.php">
                            <img src="assets/img/icon/008-accounting.svg" class="center">
                            <h4>Specialist Services</h4>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start How it Work
    ============================================= -->
    <div class="works-rules-area default-padding">
        <div class="container">
            <div class="row">
                <div class="site-heading text-center">
                    <div class="col-md-8 col-md-offset-2">
                        <h2>Work Process</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="works-rules-items">
                    <div class="col-md-4 col-sm-6">
                        <div class="item">
                            <div class="icon">
                                <i class="fas fa-flag"></i>
                            </div>
                            <div class="vertical-line">
                                <span>1</span>
                            </div>
                            <div class="info">
                                <h4>Issue Detection</h4>
                                <p>
                                    Detection can come from a user or from an alert that is sent using our monitoring software. A new support ticket will be created and assigned a severity status. The severity is typically minor, major or critical.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="item">
                            <div class="info">
                                <h4>Support Assignment</h4>
                                <p>
                                    The severity assignment will determine which ticket goes first and who will be assigned to it. This triage system ensures that critical matters are attended to first.
                                </p>
                            </div>
                            <div class="vertical-line bottom">
                                <span>2</span>
                            </div>
                            <div class="icon icon-down">
                                <i class="fas fa-user-plus"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="item">
                            <div class="icon">
                                <i class="fas fa-search"></i>
                            </div>
                            <div class="vertical-line">
                                <span>3</span>
                            </div>
                            <div class="info">
                                <h4>Assessment</h4>
                                <p>
                                    The team assigned will asses the impact of the ticket, when the incident started, whether there are related tickets and other relevant factors, such as data loss. Based on the assessment, the team decides how to resolve the matter.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="padding-top: 80px;" class="row">
                <div class="works-rules-items">
                    <div class="col-md-6 col-sm-6">
                        <div class="item">
                            <div class="info">
                                <h4>Escalation and Delegation </h4>
                                <p>
                                    If the matter can not be resolved by the assigned team, the matter will be escalated. More skilled staff members will review the work done and plot a way forward to ensure that the issue is resolved. The escalation process goes all the way to any third-party service providers that may be in the supply chain.
                                </p>
                            </div>
                            <div class="vertical-line bottom">
                                <span>4</span>
                            </div>
                            <div class="icon icon-down">
                                <i class="fas fa-chalkboard-teacher"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="item">
                            <div class="icon">
                                <i class="fas fa-file"></i>
                            </div>
                            <div class="vertical-line">
                                <span>5</span>
                            </div>
                            <div class="info">
                                <h4>Review</h4>
                                <p>
                                    Once the issue has been resolved a review will happen to find out what caused the issue, and what can be put in place to make sure that a similar problem does not occur again.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End How it Work -->

<?php include 'assets/php/footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/equal-height.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/timeline.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/custom.js"></script>

</body>
</html>