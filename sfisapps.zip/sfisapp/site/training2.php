<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Alintatech Solutions Website">

    <!-- ========== Page Title ========== -->
    <title>Alintatech Solutions | Training</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicon/site.webmanifest">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/css/flaticon-business-set.css" rel="stylesheet" />
    <link href="assets/css/magnific-popup.css" rel="stylesheet" />
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/animate.css" rel="stylesheet" />
    <link href="assets/css/bootsnav.css" rel="stylesheet" />
    <link href="style.css" rel="stylesheet">
    <link href="custom.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="assets/js/html5/html5shiv.min.js"></script>
      <script src="assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,900" rel="stylesheet">

</head>

<body>

    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-angle-double-up"></i></button>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <?php include 'assets/php/header.php' ?>
    
    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area shadow dark bg-fixed text-center padding-xl text-light" style="background-image: url(assets/img/it-training.webp);">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 text-left">
                    <h1>Training</h1>
                </div>
                <div class="col-md-6 col-sm-6 text-right">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="services.php">Managed IT Services</a></li>
                        <li><a href="recruitment.php">IT Recruitment</a></li>
                        <li class="active">Training</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Team Members
    ============================================= -->
    <div class="team-members-area item-white default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 team-member-info">
                    <div class="team-carousel-items owl-carousel owl-theme">
                        <div class="item">
                            <div class="col-md-6 thumb">
                                <img src="assets/img/java-software-introduction.webp" alt="Introduction to Java Software">
                            </div>
                            <div class="col-md-6 info title">
                                <h3>Introduction: Java Software Development</h3>
                                <p>
                                    This course is designed to help participants with very little or no actual programming experience.  background to learn the basics of Financial Markets, as a first step before entering the corporate world of Investment Banking.
                                </p>
                                <p>
                                    In this course, participants are introduced to Financial Markets 
                                </p>

                            </div>
                        </div>
                        <div class="item">
                            <div class="col-md-6 thumb">
                                <img src="assets/img/java-software-complete.webp" alt="Complete Java Software Training">
                            </div>
                            <div class="col-md-6 info title">
                                <h3>Comprehensive: Java Software Development</h3>
                                <p>
                                    This course is designed to guide participants through the concepts of Java from introductory techniques to advanced programming skills. This advanced Java course will also provide you with the knowledge of Core Java topics while giving you hands-on programming experience. The following topics are included:
                                </p>
                                <ul>
                                    <li><i class="fas fa-angle-right"></i>  Operators,</li><br>
                                    <li><i class="fas fa-angle-right"></i>  Arrays,</li>
                                    <li><i class="fas fa-angle-right"></i>  Loops, Methods, And Constructors While Giving You Hands-On Experience In JDBC and JUnit framework,</li>
                                    <li><i class="fas fa-angle-right"></i>  Advanced Java Certification Training.</li>
                                </ul>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-md-6 thumb">
                                <img src="assets/img/corporate-software-developer.webp" alt="Introduction: Corporate Software Developer">
                            </div>
                            <div class="col-md-6 info title">
                                <h3>Introduction: Corporate Software Developer</h3>
                                <p>
                                    This course is designed to be self-paced online training designed on one of the most popular platform ‘Java’, to train you on its advanced concepts of Java and gain an entry into the programming world as a Software Developer in corporate world.
                                </p>
                                <p>
                                    This is self-paced online training designed on one of the most popular platform ‘Java’, to train you on its basic and advanced concepts of Java and gain an entry into the programming world as a Java Developer.
                                </p>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-md-6 thumb">
                                <img src="assets/img/financial-markets.webp" alt="Introduction to Financial Markets">
                            </div>
                            <div class="col-md-6 info title">
                                <h3>Introduction: Corporate Markets</h3>
                                <p>
                                    This course is designed to help students with very little or no finance background to learn the basics of Financial Markets, as a first step before entering the corporate world of Investment Banking.
                                </p>
                                <p>
                                    In this course, participants are introduced to Financial Markets: 
                                </p>
                                <ul>
                                    <li><i class="fas fa-angle-right"></i>  What Financial Markets Are.</li><br>
                                    <li><i class="fas fa-angle-right"></i>  Type of Financial Markets.</li><br>
                                    <li><i class="fas fa-angle-right" style="padding-left: 30px;"></i>  Derivatives Markets.</li><br>
                                    <li><i class="fas fa-angle-right" style="padding-left: 30px;"></i>  Bond Markets.</li><br>
                                    <li><i class="fas fa-angle-right" style="padding-left: 30px;"></i>  Commodities Markets.</li><br>
                                    <li><i class="fas fa-angle-right" style="padding-left: 30px;"></i>  Stock Markets.</li><br>
                                    <li><i class="fas fa-angle-right"></i>  Use of Financial Markets.</li><br>
                                    <li><i class="fas fa-angle-right"></i>  Pricing Financial Markets instruments.</li><br>
                                    <li><i class="fas fa-angle-right" style="padding-left: 30px;"></i>  Time Value of Money.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Team Members -->

    <!-- Start Query  
    ============================================= -->
    <div class="faq-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 appoinment contact-form">
                    <h2>Request a quote</h2>
                    <form action="assets/mail/quote.php" method="POST" class="contact-form">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="name" name="name" placeholder="Name*" type="text">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="email" name="email" placeholder="Email*" type="email">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <input class="form-control" id="phone" name="phone" placeholder="Phone*" type="text">
                                    <span class="alert-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group">
                                    <label class="select-label" for="query">Training Course*:</label>
                                    <select class="select-form" name="query" id="query" form="carform">
                                        <option value="Introduction: Java Software Development">Introduction: Java Software Development</option>
                                        <option value="Comprehensive: Java Software Development">Comprehensive: Java Software Development</option>
                                        <option value="Introduction:Corporate Software Development">Introduction:Corporate Software Development</option>
                                        <option value="Introduction: Corporate Markets">Introduction: Corporate Markets</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group comments">
                                    <textarea class="form-control" id="comments" name="comments" placeholder="Tell Us About Your Project *"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                                <button type="submit" name="submit" id="submit">
                                    Send Message <i class="fa fa-paper-plane"></i>
                                </button>
                            </div>
                        </div>
                        <!-- Alert Message -->
                        <div class="col-md-12 alert-notification">
                            <div id="message" class="alert-msg"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Query -->

<?php include 'assets/php/footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/equal-height.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/timeline.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/custom.js"></script>

</body>
</html>