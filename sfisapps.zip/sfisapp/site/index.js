const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

// Helper function to serve PHP file
async function servePhpFile(phpFile, event, statusCode = 200) {
    const phpScriptPath = path.join(__dirname, phpFile);
    
    // Set up environment variables
    const env = {
        ...process.env,
        REQUEST_URI: event.path,
        REQUEST_METHOD: event.httpMethod,
        QUERY_STRING: event.queryStringParameters ? new URLSearchParams(event.queryStringParameters).toString() : '',
        REMOTE_ADDR: event.requestContext?.identity?.sourceIp || '',
        HTTP_USER_AGENT: event.headers?.['User-Agent'] || '',
        SERVER_NAME: event.headers?.Host || '',
        SERVER_PROTOCOL: 'HTTP/1.1',
        ERROR_STATUS: statusCode.toString(),
        BASE_URL: process.env.BASE_URL || '',
        ASSET_URL: process.env.ASSET_URL || ''
    };

    return new Promise((resolve, reject) => {
        const php = spawn('php-cgi', [phpScriptPath], { env });
        let output = '';
        let error = '';

        php.stdout.on('data', (data) => {
            output += data.toString();
        });

        php.stderr.on('data', (data) => {
            error += data.toString();
        });

        php.on('close', (code) => {
            if (code !== 0) {
                console.error('PHP Error:', error);
                resolve({
                    statusCode: statusCode,
                    headers: {
                        'Content-Type': 'text/html'
                    },
                    body: `<h1>${statusCode} - Error</h1>`
                });
            } else {
                const [headers, body] = parsePhpResponse(output);
                resolve({
                    statusCode: statusCode,
                    headers: {
                        'Content-Type': 'text/html',
                        ...headers
                    },
                    body: body
                });
            }
        });
    });
}

exports.handler = async (event) => {
    try {
        // Get the path from the event
        let phpFile = 'index.php'; // default
        const path_param = event.path || event.rawPath;
        
        // Map URLs to PHP files
        const routeMap = {
            '/': 'index.php',
            '/index': 'index.php',
            '/about': 'about.php',
            '/services': 'services.php',
            '/contact': 'contact.php',
            '/recruitment': 'recruitment.php',
            '/training': 'training.php'
        };

        // Handle POST requests for contact form
        if (event.httpMethod === 'POST' && event.body) {
            const postData = JSON.parse(event.body);
            env.REQUEST_METHOD = 'POST';
            env.HTTP_CONTENT_TYPE = event.headers['Content-Type'];
            env.HTTP_CONTENT_LENGTH = event.body.length;
            env.POST_DATA = JSON.stringify(postData);
        }

        // Clean the path and get corresponding PHP file
        const cleanPath = path_param.replace(/\.php$/, '');
        phpFile = routeMap[cleanPath] || 'index.php';

        // Verify file exists
        const phpScriptPath = path.join(__dirname, phpFile);
        if (!fs.existsSync(phpScriptPath)) {
            console.log(`File not found: ${phpScriptPath}`);
            return await servePhpFile('404.php', event, 404);
        }

        // Serve the requested PHP file
        return await servePhpFile(phpFile, event, 200);

    } catch (error) {
        console.error('Server Error:', error);
        return await servePhpFile('500.php', event, 500);
    }
};

// Helper function to parse PHP-CGI response
function parsePhpResponse(response) {
    const [headersStr, ...bodyParts] = response.split('\r\n\r\n');
    const body = bodyParts.join('\r\n\r\n');
    
    const headers = {};
    headersStr.split('\r\n').forEach(line => {
        const [key, value] = line.split(': ');
        if (key && value) {
            headers[key] = value;
        }
    });

    return [headers, body];
}
