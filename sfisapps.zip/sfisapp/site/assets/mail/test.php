<!DOCTYPE html>
<html>
<head>
    <title>Training Quote Form</title>
</head>
<body>
    <form action="training-quote.php" method="POST" class="contact-form">
        <div class="col-md-12">
            <div class="row">
                <div class="form-group">
                    <input class="form-control" id="name" name="name" placeholder="Name*" type="text">
                    <span class="alert-error"></span>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="form-group">
                    <input class="form-control" id="email" name="email" placeholder="Email*" type="email">
                    <span class="alert-error"></span>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="form-group">
                    <input class="form-control" id="phone" name="phone" placeholder="Phone*" type="text">
                    <span class="alert-error"></span>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="form-group">
                    <label class="select-label" for="query">Training Course*:</label>
                    <select class="select-form" name="query" id="query">
                        <option value="Introduction: Java Software Development">Introduction: Java Software Development</option>
                        <option value="Comprehensive: Java Software Development">Comprehensive: Java Software Development</option>
                        <option value="Introduction:Corporate Software Development">Introduction:Corporate Software Development</option>
                        <option value="Introduction: Corporate Markets">Introduction: Corporate Markets</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="form-group comments">
                    <textarea class="form-control" id="comments" name="comments" placeholder="Tell Us About Your Project *"></textarea>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="row">
                <button type="submit" name="submit" id="submit">
                    Send Message <i class="fa fa-paper-plane"></i>
                </button>
            </div>
        </div>
        <!-- Alert Message -->
        <div class="col-md-12 alert-notification">
            <div id="message" class="alert-msg"></div>
        </div>
    </form>
</body>
</html>
