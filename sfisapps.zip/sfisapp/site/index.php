<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-1W8M9S5KQY"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-1W8M9S5KQY');
    </script>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Alintatech Solutions Website">

    <!-- ========== Page Title ========== -->
    <title>Alintatech Solutions | Home</title>

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicon/site.webmanifest">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- <link rel="stylesheet" href="assets/css/fa/css/fontawesome.min.css" /> -->
    <link href="assets/css/flaticon-business-set.css" rel="stylesheet" />
    <link href="assets/css/magnific-popup.css" rel="stylesheet" />
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/animate.css" rel="stylesheet" />
    <link href="assets/css/bootsnav.css" rel="stylesheet" />
    <link href="style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="assets/js/html5/html5shiv.min.js"></script>
      <script src="assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,900" rel="stylesheet">

</head>

<body>

    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-angle-double-up"></i></button>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Start Header Top 
    ============================================= -->
    <div class="top-bar-area bg-theme text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="info box">
                        <ul>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-envelope-open"></i>
                                </div>
                                <div class="info">
                                    <p>
                                        <a href="mailto:info@alintatechsolutions.co.za">info@alintatechsolutions.co.za</a> 
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <div class="info">
                                    <p>
                                        <a href="tel:27871645894">+27 87 809 1201</a>
                                    </p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header 
    ============================================= -->
    <header>

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-fixed border white no-background bootsnav">

            <div class="container">

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="#brand">
                        <img src="assets/img/logo-light.svg" class="logo logo-display" alt="Logo">
                        <img src="assets/img/logo.svg" class="logo logo-scrolled" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#">
                        <li>
                            <a href="index.php" class="active">Home</a>
                        </li>
                        <li>
                            <a href="about.php">About Us</a>
                        </li>
                        <li>
                            <a href="services.php">Managed IT Services</a>
                        </li>
                        <li>
                            <a href="recruitment.php">Recruitment</a>
                        </li>
                        <li>
                            <a href="training.php">Training</a>
                        </li>
                        <li>
                            <a href="contact.php">Contact Us</a>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->

    <!-- Start Banner 
    ============================================= -->
    <div class="banner-area">
        <div id="bootcarousel" class="carousel slide transparent-nav animate_text carousel-fade" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner text-light carousel-zoom">
                <div class="item active">
                    <div class="slider-thumb bg-fixed" style="background-image: url(assets/img/banner.webp);"></div>
                    <div class="box-table shadow theme">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="col-md-8">
                                            <div class="content">
                                                <h1 data-animation="animated slideInLeft">One-Stop professional Technology Solutions delivered by an experienced and friendly team</h1>
                                                <a data-animation="animated slideInUp" class="btn btn-light effect btn-sm" href="services.php">Learn More</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="content">
                                            <ul data-animation="animated slideInRight" class="slide-list">
                                                <li><i class="fas fa-angle-double-right"></i>  Managed IT Services</li>
                                                <li><i class="fas fa-angle-double-right"></i>  Software Development</li>
                                                <li><i class="fas fa-angle-double-right"></i>  Recruitment and Staff Outsourcing</li>   
                                                <li><i class="fas fa-angle-double-right"></i>  SAP Services</li>
                                                <li><i class="fas fa-angle-double-right"></i>  Sage Pastel</li>
                                                <li><i class="fas fa-angle-double-right"></i>  IT Relocation</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <!-- Start Features 
    ============================================= -->
    <div class="features-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="features-items">
                        <div class="col-md-4">
                            <div class="item">
                                <div class="icon">
                                    <img style="padding-bottom: 40px;width: 100px;" src="assets/img/icon/003-technical-support.svg" class="center">
                                </div>
                                <div class="info">
                                    <h4>Managed IT Services</h4>
                                    <p>
                                        The Alinta Tech Engineers and Technicians are dedicated and friendly professionals with expertise in Server Management, Strategic IT advisory, Cloud Services, Network Management and IT Security, Office 365, VOIP... 
                                    </p>
                                    <a href="services.php">Read More<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="item">
                                <div class="icon">
                                    <img style="padding-bottom: 40px;width: 100px;" src="assets/img/icon/007-coding.svg" class="center">
                                </div>
                                <div class="info">
                                    <h4>Software Development</h4>
                                    <p>
                                    Alinta Tech offers professional and affordable software development solutions. We can assist you with most software development and integration. We offer affordable payment options that can be incorporated...
                                    </p>
                                    <a href="services.php">Read More<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="item">
                                <div class="icon">
                                    <img style="padding-bottom: 40px;width: 100px;" width="" src="assets/img/icon/006-recruitment-1.svg" class="center">
                                </div>
                                <div class="info">
                                    <h4>Recruitment and Staff Outsourcing</h4>
                                    <p>
                                        We keep your recruitment needs simple. As an established Managed IT solutions company, first and foremost, Alinta Tech has a better understanding than most about finding and placing hard-to-find permanent... 
                                    </p>
                                    <a href="recruitment.php">Read More<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Features -->

    <!-- Start Services 
    ============================================= -->
    <section class="services-area default-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="service-carousel text-center text-light owl-carousel owl-theme">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End services area-->

    <!-- Start Services 
    ============================================= -->
    <div class="tab-services-area bg-gray">
        <div class="container-box oh">
            <div class="col-md-6 thumb bg-cover" style="background-image: url(assets/img/managed-services.webp);"></div>
            <div class="col-md-6 services-item">
                <!-- Start Tab Content -->
                <div class="tab-content tab-content-info">
                    <div id="tab5" class="tab-pane fade active in">
                        <div class="info title">
                            <h2>Managed IT Support Services</h2>
                            <p>
                                The Alinta Tech Engineers and Technicians are dedicated and friendly professionals with expertise in Server Management, Strategic IT advisory, Cloud Services, Network Management and IT Security, Office 365, VOIP and many other end user technologies.
                            </p>
                            <p>
                                This enables Alinta Tech to provide a full range of managed services from desktop support to small business through to fully outsourced IT to medium-sized enterprises in and around Gauteng mostly, but at selected localities outside Gauteng.
                            </p>
                            <p>
                                Tell us about your technology challenges and we will design a solution that will harness the technology to take your company forward.
                            </p>
                            <a data-animation="animated slideInUp" class="btn btn-theme effect btn-sm" href="services.php">Learn more</a>
                        </div>
                    </div>
                </div>
                <!-- End Tab Content -->
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Footer -->
    <?php include 'assets/php/footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/equal-height.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/timeline.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/custom.js"></script>

</body>
</html>